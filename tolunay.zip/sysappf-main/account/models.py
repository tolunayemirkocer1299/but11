from unittest.util import _MAX_LENGTH
from django.db import models

class rozet(models.Model):
    r = models.TextField()
    dtsitle = models.TextField()

class damga(models.Model):
    duser = models.TextField()
    dtitle = models.TextField()