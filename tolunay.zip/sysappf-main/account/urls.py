from django.urls import path
from . import views
from django.contrib.auth import views as auth_views

urlpatterns = [
    path("login", views.login_request, name="login"),
    path("register", views.register_request, name="register"),
    path("logout", views.logout_request, name="logout"),
    path("profil", views.profil, name="profil"),
    path("ayarlar",views.ayarlar, name="ayarlar"),
    path("password", auth_views.PasswordChangeView.as_view(template_name="account/setpassword.html"), name="setpassword"),
    path("dashrozet",views.rozet, name="dashrozet"),
    path("dashrozetdel",views.delrozet, name="dashrozetdel"),
    #path("lgn",views.lgn_request, name="lgn"),
]