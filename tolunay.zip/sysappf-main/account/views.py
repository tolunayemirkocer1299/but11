import re
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from account.models import damga


def login_request(request):
    if request.user.is_authenticated:
        return redirect("home")

    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(request, username = username, password = password)

        if user is not None:
            login(request, user)
            return redirect("home")

        else:
            return render(request, "account/login.html", {
                "error": "kullanıcı adı yada şifre hatalı lütfen bidaha deneyiniz."
            })
    return render(request, "account/login.html")

def register_request(request):
    if request.user.is_authenticated:
        return redirect("home")

    if request.method == "POST":
        username = request.POST["username"]
        isim = request.POST["isim"]
        email = request.POST["email"]
        password = request.POST["password"]
        repassword = request.POST["repassword"]
        if password == repassword:
            if User.objects.filter(username=username).exists():
                return (request, "account/register.html", {"error": "username kullanılıyor"})
            else:
                if User.objects.filter(email=email).exists():
                    return (request, "account/register.html", {"error": "email kullanılıyor"})
                else:
                    user = User.objects.create_user(username=username,email=email,first_name=isim,password=password)
                    user.save()
                    return redirect("login")
            
        else:
            return render(request, "account/register.html", {"error": "parola eşleşmiyor"})

    
    return render(request, "account/register.html")

def logout_request(request):
    logout(request)
    return redirect("home")

def profil(request):
    if not request.user.is_authenticated:
        return redirect("register")
    context = {
        "drozet": damga.objects.all(),
        "tuser": User.objects.all(),
    }
    return render(request, "account/profil.html", context)

def ayarlar(request):
    if not request.user.is_authenticated:
        return redirect("register")
    return render(request, "account/ayarlar.html")

def username(request):
    if not request.user.is_authenticated:
        return redirect("register")
    if request.method == "POST":
        newusername = request.POST["newusername"]
        user = User.objects.all()
        user.username = newusername
        user.save()

    return render(request, "account/setname.html")

def rozet(request):
    if not request.user.is_staff:
        return redirect("home")
    if request.method == "POST":
        isim = request.POST["usrnm"]
        title = request.POST["usrtitle"]
        dss = damga.objects.create(duser = isim, dtitle = title)
        dss.save()
    return render(request, "account/dashrozet.html")

def delrozet(request):
    if not request.user.is_staff:
        return redirect("home")
    if request.method == "POST":
        deletetitle = request.POST["deltitle"]
        des = damga.objects.filter(dtitle = deletetitle).delete()
    return render(request, "account/dashrozetdel.html")
